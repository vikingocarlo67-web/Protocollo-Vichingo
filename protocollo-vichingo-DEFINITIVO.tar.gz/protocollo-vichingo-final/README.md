# PROTOCOLLO VICHINGO - Calcolatore Redistribuzione Fiscale

## La Verità in Numeri

**€12.69 MILIARDI** di gap fiscale annuale non redistribuito dai giganti.

---

## 🚀 QUICK START

### Local Development
```bash
npm install
npm run dev
```
Accedi a `http://localhost:3000`

### Production Build
```bash
npm run build
npm start
```

---

## 📊 DATABASE

Il file `lib/data.ts` contiene TUTTI i dati:

**Settori Monitorati:**
- 🔵 Big Tech (Amazon, Google, Meta, Apple)
- 💊 Big Pharma (Pfizer, Novartis, Roche)
- ⛽ Big Oil (Eni, Shell, TotalEnergies)
- 🌾 Grano/Agro (Barilla, Bunge, Casillo)
- 🥩 Animali/Latticini (Inalca, Granarolo, Parmalat)
- 🛣️ Autostrade (ASPI, Mundys, Pedemontana)
- 👓 Ottica (EssilorLuxottica)
- 🏎️ Auto (Ferrari, Lamborghini, Iveco)
- 📞 Telecom (WindTre, Vodafone, TIM, Iliad)
- 💰 Banche (Intesa, UniCredit)
- 🛒 GDO (Coop, Conad, Esselunga)
- 🏭 Cemento (Italcementi, Buzzi)

**Fonte Dati:**
- Bilanci pubblici 2025
- ANAC 2025
- Report settoriali ufficiali
- Proiezioni 2026

---

## 🎯 DEPLOYMENT

### Vercel (Consigliato)
```bash
npm install -g vercel
vercel
```

### GitHub Pages (Statico)
```bash
npm run build
# Carica la cartella `.next` su GitHub Pages
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm install && npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

---

## 📧 CONTATTI

**Email:** protocollo.vichingo@proton.me  
**Data:** Febbraio 2026  
**Motto:** "L'ordine nasce dal caos quando la misura incontra la pazienza"

---

## 📜 COME FUNZIONA

1. **DATI REALI** - Fatturati e tasse pubbliche verificate
2. **PATENTE DIGITALE** - Aliquota minima 12% (come un panettiere)
3. **REDISTRIBUZIONE** - 50% del gap va ai cittadini italiani
4. **RESPONSABILITÀ SOLIDALE** - Fornitori locali rispondono se il gigante non paga

---

## 🎨 DESIGN

**Estetica:** Brutale, senza fronzoli. Puro ferro.
- **Colori:** Nero, Rosso (#dc2626), Giallo (#fbbf24)
- **Font:** Monospace (Courier)
- **Vibe:** Manifesto politico anni '70

---

## ⚠️ NOTE LEGALI

Tutti i dati sono pubblici e verificabili da fonti ufficiali.  
Il calcolatore fornisce stime basate su aliquote fiscali standard italiane.  
Non è consulenza fiscale.

---

## 🛠️ TECH STACK

- **React 18**
- **Next.js 14**
- **TypeScript**
- **Tailwind CSS**
- **Framer Motion** (animazioni)

---

**Protocollo Vichingo - La Verità che Non Puoi Ignorare**
