/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        'viking-dark': '#1a1a1a',
        'viking-blue': '#0ea5e9',
        'viking-ice': '#06b6d4',
        'viking-gold': '#fbbf24',
        'viking-red': '#dc2626',
      },
    },
  },
  plugins: [],
};
