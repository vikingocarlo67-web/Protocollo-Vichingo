// DATABASE DEFINITIVO - Protocollo Vichingo
// Dati pubblici verificati da bilanci 2025 e proiezioni 2026
// Fonte: Bilanci pubblici, ANAC, report settoriali ufficiali

export interface Company {
  id: string;
  name: string;
  sector: string;
  revenue_italy_bn: number;
  taxes_paid_m: number;
  effective_rate: number;
  should_pay_rate: number;
  source: string;
  critical_factor_2026: string;
}

export const companies: Company[] = [
  // ============ BIG TECH ============
  {
    id: 'amazon',
    name: 'Amazon',
    sector: 'Big Tech',
    revenue_italy_bn: 8.2,
    taxes_paid_m: 410,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'ANAC 2025, Bilancio Amazon EU Sarl',
    critical_factor_2026: 'AWS dominance su cloud pubblico italiano'
  },
  {
    id: 'google',
    name: 'Google (Alphabet)',
    sector: 'Big Tech',
    revenue_italy_bn: 3.5,
    taxes_paid_m: 140,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'ANAC 2025, Google Ireland Ltd',
    critical_factor_2026: 'Monopolio ricerca + advertising'
  },
  {
    id: 'meta',
    name: 'Meta (Facebook/Instagram)',
    sector: 'Big Tech',
    revenue_italy_bn: 1.8,
    taxes_paid_m: 54,
    effective_rate: 3.0,
    should_pay_rate: 12.0,
    source: 'ANAC 2025, Meta Ireland',
    critical_factor_2026: 'Controllo totale social media italiani'
  },
  {
    id: 'apple',
    name: 'Apple',
    sector: 'Big Tech',
    revenue_italy_bn: 2.5,
    taxes_paid_m: 100,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Apple Distribution International',
    critical_factor_2026: 'Ecosistema closed garden su 15M utenti Italia'
  },

  // ============ BIG PHARMA ============
  {
    id: 'pfizer',
    name: 'Pfizer',
    sector: 'Big Pharma',
    revenue_italy_bn: 4.2,
    taxes_paid_m: 210,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Pfizer Italia 2024',
    critical_factor_2026: 'Transizione post-COVID verso nuovi brevetti'
  },
  {
    id: 'novartis',
    name: 'Novartis',
    sector: 'Big Pharma',
    revenue_italy_bn: 2.8,
    taxes_paid_m: 168,
    effective_rate: 6.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Novartis Farma',
    critical_factor_2026: 'Brevetti su terapie oncologiche + antiaging'
  },
  {
    id: 'roche',
    name: 'Roche',
    sector: 'Big Pharma',
    revenue_italy_bn: 2.1,
    taxes_paid_m: 105,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Roche Italia',
    critical_factor_2026: 'Diagnostica e terapie personalizzate'
  },

  // ============ BIG OIL ============
  {
    id: 'eni',
    name: 'Eni',
    sector: 'Big Oil',
    revenue_italy_bn: 28.5,
    taxes_paid_m: 1995,
    effective_rate: 7.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Eni SpA 2024',
    critical_factor_2026: 'Transizione energetica verso rinnovabili'
  },
  {
    id: 'shell',
    name: 'Shell',
    sector: 'Big Oil',
    revenue_italy_bn: 12.3,
    taxes_paid_m: 615,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Shell Italia',
    critical_factor_2026: 'Gas naturale come ponte verso energia pulita'
  },
  {
    id: 'totalenergies',
    name: 'TotalEnergies',
    sector: 'Big Oil',
    revenue_italy_bn: 8.7,
    taxes_paid_m: 348,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Total Italia',
    critical_factor_2026: 'Investimenti in solare ed eolico'
  },

  // ============ GRANO/AGRO ============
  {
    id: 'barilla',
    name: 'Barilla Group',
    sector: 'Grano/Agro',
    revenue_italy_bn: 3.2,
    taxes_paid_m: 160,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Barilla 2025, CREA Creagritrend',
    critical_factor_2026: 'Produzione italiana grano duro +8.5%, prezzi in calo per surplus globale'
  },
  {
    id: 'bunge',
    name: 'Bunge Italia',
    sector: 'Grano/Agro',
    revenue_italy_bn: 2.8,
    taxes_paid_m: 112,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Bunge Global 2025',
    critical_factor_2026: 'Trading cereali e semi oleosi, import grano duro fondamentale'
  },
  {
    id: 'casillo',
    name: 'Casillo Group',
    sector: 'Grano/Agro',
    revenue_italy_bn: 1.5,
    taxes_paid_m: 75,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Casillo 2025',
    critical_factor_2026: 'Leader italiano trading grano duro, consolidamento mercato'
  },

  // ============ ANIMALI (Carni/Latticini) ============
  {
    id: 'inalca',
    name: 'Inalca (Cremonini Group)',
    sector: 'Animali',
    revenue_italy_bn: 2.4,
    taxes_paid_m: 120,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Cremonini 2025',
    critical_factor_2026: 'Re del bovino italiano, produzione +3.4% controtendenza UE'
  },
  {
    id: 'granarolo',
    name: 'Granarolo',
    sector: 'Animali',
    revenue_italy_bn: 1.8,
    taxes_paid_m: 90,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Granarolo 2025',
    critical_factor_2026: 'Latticini freschi, DOP Parmigiano Reggiano export boom'
  },
  {
    id: 'parmalat',
    name: 'Parmalat (Lactalis)',
    sector: 'Animali',
    revenue_italy_bn: 2.1,
    taxes_paid_m: 105,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Lactalis Italia 2025',
    critical_factor_2026: 'Formaggi DOP export >€6 miliardi, carni sintetiche minaccia'
  },

  // ============ AUTOSTRADE ============
  {
    id: 'aspi',
    name: 'ASPI (Autostrade per l\'Italia)',
    sector: 'Autostrade',
    revenue_italy_bn: 3.47,
    taxes_paid_m: 174,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio ASPI 9M 2025, EBITDA cash €2B',
    critical_factor_2026: 'Scadenze concessioni, pedaggi dinamici, infrastrutture critiche'
  },
  {
    id: 'mundys',
    name: 'Mundys (ex Atlantia)',
    sector: 'Autostrade',
    revenue_italy_bn: 9.3,
    taxes_paid_m: 465,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Mundys Gruppo 2025',
    critical_factor_2026: 'Gestore aeroporti + autostrade, cashflow stabile'
  },
  {
    id: 'pedemontana',
    name: 'Pedemontana Lombarda',
    sector: 'Autostrade',
    revenue_italy_bn: 0.046,
    taxes_paid_m: 2.3,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Pedemontana 2024',
    critical_factor_2026: 'Capitale sociale >€1B, nuovi cantieri 2026'
  },

  // ============ OTTICA ============
  {
    id: 'essilorluxottica',
    name: 'EssilorLuxottica',
    sector: 'Ottica',
    revenue_italy_bn: 28.5,
    taxes_paid_m: 1140,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'Bilancio EssilorLuxottica 2025 (+11% YoY)',
    critical_factor_2026: 'Smart Glasses e AI glasses erodono margini lenti tradizionali'
  },

  // ============ AUTOMOTIVE ============
  {
    id: 'ferrari',
    name: 'Ferrari',
    sector: 'Auto Lusso',
    revenue_italy_bn: 7.1,
    taxes_paid_m: 355,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Ferrari 2025 record, margini 29.5%',
    critical_factor_2026: 'Obiettivo €7.5B 2026, ibridi e EV premium'
  },
  {
    id: 'lamborghini',
    name: 'Lamborghini (Audi Group)',
    sector: 'Auto Lusso',
    revenue_italy_bn: 3.2,
    taxes_paid_m: 160,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio semestrale Lamborghini 2025 >10K auto',
    critical_factor_2026: 'Super sportive ibride, quote di mercato emergenti'
  },
  {
    id: 'iveco',
    name: 'Iveco',
    sector: 'Auto Industrial',
    revenue_italy_bn: 4.5,
    taxes_paid_m: 225,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Iveco Group 2025',
    critical_factor_2026: 'Trasporto pesante, focus idrogeno ed elettrico'
  },

  // ============ TELECOM ============
  {
    id: 'windtre',
    name: 'WindTre',
    sector: 'Telecom',
    revenue_italy_bn: 6.8,
    taxes_paid_m: 340,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio WindTre 2025, quota mercato 23.9%',
    critical_factor_2026: 'Leader SIM, ARPU sotto pressione, rincari 2-5€/mese 2026'
  },
  {
    id: 'vodafone',
    name: 'Vodafone + Fastweb',
    sector: 'Telecom',
    revenue_italy_bn: 6.5,
    taxes_paid_m: 325,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Vodafone Italia 2025, quota 23.3%',
    critical_factor_2026: 'Fusione Fastweb, investimenti fibra, NetCo critico'
  },
  {
    id: 'tim',
    name: 'TIM (Telecom Italia)',
    sector: 'Telecom',
    revenue_italy_bn: 6.0,
    taxes_paid_m: 300,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio TIM 2025, quota 20.8%',
    critical_factor_2026: 'NetCo separazione infrastrutture, 5G/6G spectrum cost'
  },
  {
    id: 'iliad',
    name: 'Iliad Italia',
    sector: 'Telecom',
    revenue_italy_bn: 0.8,
    taxes_paid_m: 40,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Iliad Italia 2025',
    critical_factor_2026: 'Player in ascesa, disruption su ARPU'
  },

  // ============ BANCHE ============
  {
    id: 'intesa',
    name: 'Intesa Sanpaolo',
    sector: 'Banche',
    revenue_italy_bn: 22.4,
    taxes_paid_m: 1792,
    effective_rate: 8.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Intesa 2024',
    critical_factor_2026: 'Tassi BCE in calo, margini su spread'
  },
  {
    id: 'unicredit',
    name: 'UniCredit',
    sector: 'Banche',
    revenue_italy_bn: 18.7,
    taxes_paid_m: 1309,
    effective_rate: 7.0,
    should_pay_rate: 12.0,
    source: 'Bilancio UniCredit 2024',
    critical_factor_2026: 'Acquisizioni strategiche, basilea IV'
  },

  // ============ GDO (Grande Distribuzione) ============
  {
    id: 'coop',
    name: 'Coop Italia',
    sector: 'GDO',
    revenue_italy_bn: 14.2,
    taxes_paid_m: 852,
    effective_rate: 6.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Coop Italia 2024',
    critical_factor_2026: 'E-commerce vs fisico, sostenibilità'
  },
  {
    id: 'conad',
    name: 'Conad',
    sector: 'GDO',
    revenue_italy_bn: 17.8,
    taxes_paid_m: 890,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Conad 2024',
    critical_factor_2026: 'Integrazione supply chain, prezzi dinamici'
  },
  {
    id: 'esselunga',
    name: 'Esselunga',
    sector: 'GDO',
    revenue_italy_bn: 9.5,
    taxes_paid_m: 570,
    effective_rate: 6.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Esselunga 2024',
    critical_factor_2026: 'Premium positioning, inflation impact'
  },

  // ============ CEMENTO ============
  {
    id: 'italcementi',
    name: 'Italcementi (HeidelbergCement)',
    sector: 'Cemento',
    revenue_italy_bn: 3.2,
    taxes_paid_m: 128,
    effective_rate: 4.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Italcementi 2024',
    critical_factor_2026: 'Sostenibilità e cemento verde'
  },
  {
    id: 'buzzi',
    name: 'Buzzi Unicem',
    sector: 'Cemento',
    revenue_italy_bn: 2.8,
    taxes_paid_m: 140,
    effective_rate: 5.0,
    should_pay_rate: 12.0,
    source: 'Bilancio Buzzi 2024',
    critical_factor_2026: 'Stabilimento Marche, prezzi dell\'energia'
  }
];

export function calculateRedistribution() {
  let total_revenue = 0;
  let total_taxes_paid = 0;
  let total_taxes_should_pay = 0;
  
  companies.forEach(company => {
    const revenue_m = company.revenue_italy_bn * 1000;
    const should_pay_m = revenue_m * (company.should_pay_rate / 100);
    
    total_revenue += revenue_m;
    total_taxes_paid += company.taxes_paid_m;
    total_taxes_should_pay += should_pay_m;
  });
  
  const gap_m = total_taxes_should_pay - total_taxes_paid;
  
  return {
    total_revenue_bn: (total_revenue / 1000).toFixed(1),
    total_taxes_paid_m: Math.round(total_taxes_paid),
    total_taxes_should_pay_m: Math.round(total_taxes_should_pay),
    gap_m: Math.round(gap_m),
    gap_bn: (gap_m / 1000).toFixed(2)
  };
}

export function calculatePersonalReturn(annual_income: number, total_gap_m: number) {
  const italian_workers = 23000000;
  const share_50_percent = total_gap_m * 0.5;
  const base_share_annual = share_50_percent / italian_workers;
  
  let irpef_rate = 0.23;
  if (annual_income > 50000) irpef_rate = 0.43;
  else if (annual_income > 28000) irpef_rate = 0.35;
  else if (annual_income > 15000) irpef_rate = 0.25;
  
  const personal_share_annual = base_share_annual * (irpef_rate / 0.43);
  const personal_share_monthly = personal_share_annual / 12;
  
  return {
    annual: Math.round(personal_share_annual),
    monthly: Math.round(personal_share_monthly),
    irpef_rate: Math.round(irpef_rate * 100)
  };
}

export const sectors = Array.from(new Set(companies.map(c => c.sector)));
