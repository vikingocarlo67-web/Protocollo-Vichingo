'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { companies, calculateRedistribution, calculatePersonalReturn, sectors } from '../lib/data';

export default function Home() {
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedSector, setSelectedSector] = useState('');
  const [userIncome, setUserIncome] = useState(28000);
  const [results, setResults] = useState<any>(null);
  const [showTotal, setShowTotal] = useState(false);
  const [activeTab, setActiveTab] = useState('calculator');

  const redistData = calculateRedistribution();

  const handleCalculate = () => {
    const company = companies.find(c => c.id === selectedCompany);
    if (!company) return;

    const revenue_m = company.revenue_italy_bn * 1000;
    const should_pay_m = revenue_m * (company.should_pay_rate / 100);
    const gap_m = should_pay_m - company.taxes_paid_m;

    const personalReturn = calculatePersonalReturn(userIncome, gap_m);

    setResults({
      company: company.name,
      sector: company.sector,
      revenue_bn: company.revenue_italy_bn,
      taxes_paid_m: company.taxes_paid_m,
      effective_rate: company.effective_rate,
      should_pay_m: Math.round(should_pay_m),
      should_pay_rate: company.should_pay_rate,
      gap_m: Math.round(gap_m),
      personal_monthly: personalReturn.monthly,
      personal_annual: personalReturn.annual,
      source: company.source,
      critical_factor: company.critical_factor_2026
    });
    setShowTotal(false);
  };

  const handleCalculateTotal = () => {
    const personalReturn = calculatePersonalReturn(userIncome, parseInt(redistData.gap_m));
    
    setShowTotal(true);
    setResults({
      isTotal: true,
      total_revenue_bn: redistData.total_revenue_bn,
      total_taxes_paid_m: redistData.total_taxes_paid_m,
      total_should_pay_m: redistData.total_taxes_should_pay_m,
      gap_m: redistData.gap_m,
      gap_bn: redistData.gap_bn,
      personal_monthly: personalReturn.monthly,
      personal_annual: personalReturn.annual
    });
  };

  const filteredCompanies = selectedSector 
    ? companies.filter(c => c.sector === selectedSector)
    : companies;

  return (
    <div className="min-h-screen bg-black text-white font-mono">
      {/* HERO - BRUTALE */}
      <header className="relative border-b-4 border-red-600 py-24 px-8">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="max-w-7xl mx-auto text-center"
        >
          <h1 className="text-7xl md:text-9xl font-black mb-6 text-white" style={{textShadow: '3px 3px 0px #dc2626'}}>
            PROTOCOLLO VICHINGO
          </h1>
          <h2 className="text-3xl md:text-5xl mb-8 text-red-600 font-bold">
            € {redistData.gap_bn} MILIARDI NON REDISTRIBUITI
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Mentre un panettiere paga il <span className="text-red-600 font-bold">50%</span> di tasse,<br/>
            questi giganti pagano il <span className="text-red-600 font-bold">4-8%</span>.<br/>
            <span className="text-yellow-300 font-bold">I DATI NON MENTONO.</span>
          </p>
        </motion.div>

        {/* STATS BANNER */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-7xl mx-auto mt-16 grid grid-cols-1 md:grid-cols-4 gap-4 px-4"
        >
          <div className="border-4 border-yellow-300 bg-gray-900 p-6">
            <div className="text-4xl font-black text-yellow-300">€{redistData.total_revenue_bn}Mld</div>
            <div className="text-sm text-gray-400 mt-2 uppercase">Fatturato annuo</div>
          </div>
          <div className="border-4 border-red-600 bg-gray-900 p-6">
            <div className="text-4xl font-black text-red-600">€{redistData.gap_bn}Mld</div>
            <div className="text-sm text-gray-400 mt-2 uppercase">NON redistribuiti</div>
          </div>
          <div className="border-4 border-blue-500 bg-gray-900 p-6">
            <div className="text-4xl font-black text-blue-500">{companies.length}</div>
            <div className="text-sm text-gray-400 mt-2 uppercase">Aziende monitorate</div>
          </div>
          <div className="border-4 border-green-500 bg-gray-900 p-6">
            <div className="text-4xl font-black text-green-500">+€{Math.round(calculatePersonalReturn(28000, parseInt(redistData.gap_m)).monthly)}</div>
            <div className="text-sm text-gray-400 mt-2 uppercase">Per te al mese</div>
          </div>
        </motion.div>
      </header>

      {/* MAIN CONTENT */}
      <main className="max-w-7xl mx-auto px-8 py-16">
        
        {/* TABS */}
        <div className="flex gap-4 mb-12 border-b-2 border-gray-700">
          <button
            onClick={() => setActiveTab('calculator')}
            className={`py-4 px-8 text-xl font-bold uppercase ${activeTab === 'calculator' ? 'border-b-4 border-red-600 text-red-600' : 'text-gray-400'}`}
          >
            Calcolatore
          </button>
          <button
            onClick={() => setActiveTab('sectors')}
            className={`py-4 px-8 text-xl font-bold uppercase ${activeTab === 'sectors' ? 'border-b-4 border-red-600 text-red-600' : 'text-gray-400'}`}
          >
            Per Settore
          </button>
          <button
            onClick={() => setActiveTab('info')}
            className={`py-4 px-8 text-xl font-bold uppercase ${activeTab === 'info' ? 'border-b-4 border-red-600 text-red-600' : 'text-gray-400'}`}
          >
            Come Funziona
          </button>
        </div>

        {/* CALCULATOR TAB */}
        {activeTab === 'calculator' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-8"
          >
            <div className="bg-gray-900 border-4 border-yellow-300 p-12">
              <h2 className="text-4xl font-black mb-12 text-yellow-300">CALCOLA LA TUA REDISTRIBUZIONE</h2>

              {/* INCOME INPUT */}
              <div className="mb-8">
                <label className="block text-xl font-bold mb-4 text-yellow-300 uppercase">Il tuo reddito annuo (€)</label>
                <input
                  type="number"
                  value={userIncome}
                  onChange={(e) => setUserIncome(parseInt(e.target.value) || 0)}
                  className="w-full bg-black border-4 border-yellow-300 px-6 py-4 text-3xl font-black text-white focus:outline-none"
                  placeholder="28000"
                />
              </div>

              {/* COMPANY SELECTOR */}
              <div className="mb-8">
                <label className="block text-xl font-bold mb-4 text-yellow-300 uppercase">Scegli un'azienda</label>
                <select
                  value={selectedCompany}
                  onChange={(e) => setSelectedCompany(e.target.value)}
                  className="w-full bg-black border-4 border-yellow-300 px-6 py-4 text-lg text-white font-bold focus:outline-none"
                >
                  <option value="">-- Scegli --</option>
                  {sectors.map(sector => (
                    <optgroup key={sector} label={sector}>
                      {companies
                        .filter(c => c.sector === sector)
                        .map(company => (
                          <option key={company.id} value={company.id}>
                            {company.name}
                          </option>
                        ))}
                    </optgroup>
                  ))}
                </select>
              </div>

              {/* BUTTONS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  onClick={handleCalculate}
                  disabled={!selectedCompany}
                  className={`py-6 px-8 text-2xl font-black uppercase transition ${
                    selectedCompany
                      ? 'bg-yellow-300 text-black hover:bg-yellow-400'
                      : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  CALCOLA SINGOLA
                </button>

                <button
                  onClick={handleCalculateTotal}
                  className="py-6 px-8 text-2xl font-black uppercase bg-red-600 text-white hover:bg-red-700 transition"
                >
                  CALCOLA TOTALE
                </button>
              </div>
            </div>

            {/* RESULTS */}
            {results && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                {!results.isTotal && (
                  <>
                    <div className="bg-gray-900 border-4 border-blue-500 p-8">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Fatturato</div>
                          <div className="text-3xl font-black text-blue-500">€{results.revenue_bn}Mld</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Tasse Pagate</div>
                          <div className="text-3xl font-black text-blue-500">€{results.taxes_paid_m}M</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Aliquota Reale</div>
                          <div className="text-3xl font-black text-blue-500">{results.effective_rate}%</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Dovrebbe Pagare</div>
                          <div className="text-3xl font-black text-blue-500">€{results.should_pay_m}M</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-red-950 border-4 border-red-600 p-8">
                      <div className="text-center">
                        <div className="text-xl text-red-300 mb-4 uppercase">🔴 GAP NON REDISTRIBUITO</div>
                        <div className="text-6xl font-black text-red-500">€{results.gap_m}M</div>
                        <div className="text-sm text-red-300 mt-2">Sottratto allo Stato italiano</div>
                      </div>
                    </div>

                    <div className="text-sm text-gray-500 text-center italic">
                      Fonte: {results.source}
                    </div>
                  </>
                )}

                {results.isTotal && (
                  <>
                    <div className="bg-gray-900 border-4 border-blue-500 p-8">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Fatturato Totale</div>
                          <div className="text-3xl font-black text-blue-500">€{results.total_revenue_bn}Mld</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Tasse Pagate</div>
                          <div className="text-3xl font-black text-blue-500">€{results.total_taxes_paid_m}M</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Dovrebbero Pagare</div>
                          <div className="text-3xl font-black text-blue-500">€{results.total_should_pay_m}M</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400 uppercase">Gap Totale</div>
                          <div className="text-3xl font-black text-red-600">€{results.gap_bn}Mld</div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* THE BIG REVEAL */}
                <div className="bg-green-950 border-4 border-green-500 p-12 text-center">
                  <div className="text-3xl text-green-300 mb-4 uppercase font-bold">⚔️ SE {results.isTotal ? 'TUTTI' : results.company.toUpperCase()} PAGASSE{results.isTotal ? 'RO' : ''} IL GIUSTO:</div>
                  <div className="text-8xl font-black text-green-400 mb-2">+€{results.personal_monthly}</div>
                  <div className="text-3xl text-green-300 font-bold">AL MESE, PER SEMPRE</div>
                  <div className="text-lg text-green-200 mt-4">(€{results.personal_annual}/anno - basato su reddito €{userIncome.toLocaleString()})</div>
                </div>

                {/* EQUIVALENZE */}
                <div className="bg-gray-900 border-4 border-yellow-300 p-8">
                  <div className="text-2xl font-black text-yellow-300 mb-6">💡 Equivalente a:</div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border-2 border-yellow-300 p-4">
                      <div className="text-3xl font-black text-yellow-300">{Math.round(results.personal_monthly / 200)}</div>
                      <div className="text-sm text-gray-400 uppercase">settimane di spesa</div>
                    </div>
                    <div className="border-2 border-yellow-300 p-4">
                      <div className="text-3xl font-black text-yellow-300">{Math.round(results.personal_annual / 1500)}</div>
                      <div className="text-sm text-gray-400 uppercase">mesi di affitto</div>
                    </div>
                    <div className="border-2 border-yellow-300 p-4">
                      <div className="text-3xl font-black text-yellow-300">{Math.round(results.personal_annual / 2000)}</div>
                      <div className="text-sm text-gray-400 uppercase">bollette annuali</div>
                    </div>
                  </div>
                </div>

                {/* SHARE */}
                <div className="flex flex-col md:flex-row gap-4">
                  <button
                    onClick={() => {
                      const text = results.isTotal
                        ? `Se TUTTE le multinazionali pagassero il giusto, io avrei +€${results.personal_monthly}/mese! 🔥 #ProtocolloVichingo #RedistribuzioneOra`
                        : `Se ${results.company} pagasse il giusto, io avrei +€${results.personal_monthly}/mese! ⚔️ #ProtocolloVichingo #RedistribuzioneOra`;
                      navigator.clipboard.writeText(text);
                      alert('Testo copiato!');
                    }}
                    className="flex-1 py-4 px-6 bg-blue-600 text-white font-bold text-lg hover:bg-blue-700 uppercase border-2 border-blue-400"
                  >
                    📋 COPIA PER SOCIAL
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* SECTORS TAB */}
        {activeTab === 'sectors' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
            <div className="bg-gray-900 border-4 border-yellow-300 p-8">
              <h2 className="text-4xl font-black mb-8 text-yellow-300">ESPLORA PER SETTORE</h2>
              
              <div className="mb-8">
                <select
                  value={selectedSector}
                  onChange={(e) => setSelectedSector(e.target.value)}
                  className="w-full bg-black border-4 border-yellow-300 px-6 py-4 text-lg text-white font-bold"
                >
                  <option value="">Tutti i settori</option>
                  {sectors.map(sector => (
                    <option key={sector} value={sector}>{sector}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {filteredCompanies.map(company => (
                  <motion.div
                    key={company.id}
                    whileHover={{ scale: 1.02 }}
                    className="border-3 border-gray-700 bg-black p-6 hover:border-yellow-300 cursor-pointer transition"
                    onClick={() => {
                      setSelectedCompany(company.id);
                      setActiveTab('calculator');
                      setTimeout(() => handleCalculate(), 100);
                    }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="text-2xl font-black text-white">{company.name}</div>
                        <div className="text-sm text-gray-400 uppercase">{company.sector}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-black text-red-600">€{company.gap_bn || (company.revenue_italy_bn * 1000 * (company.should_pay_rate - company.effective_rate) / 100 / 1000).toFixed(2)}Mld</div>
                        <div className="text-sm text-gray-400">gap 2026</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-gray-400">Fatturato</div>
                        <div className="text-xl font-black text-white">€{company.revenue_italy_bn}Mld</div>
                      </div>
                      <div>
                        <div className="text-gray-400">Tasse Pagate</div>
                        <div className="text-xl font-black text-white">{company.effective_rate}%</div>
                      </div>
                      <div>
                        <div className="text-gray-400">Dovrebbe</div>
                        <div className="text-xl font-black text-yellow-300">{company.should_pay_rate}%</div>
                      </div>
                    </div>
                    <div className="mt-4 text-sm text-gray-500 italic border-t border-gray-700 pt-4">
                      📌 2026: {company.critical_factor_2026}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* INFO TAB */}
        {activeTab === 'info' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
            <div className="bg-gray-900 border-4 border-yellow-300 p-12">
              <h2 className="text-4xl font-black mb-12 text-yellow-300">COME FUNZIONA</h2>
              
              <div className="space-y-8">
                <div className="border-l-4 border-red-600 pl-8">
                  <h3 className="text-3xl font-black text-red-600 mb-4">1️⃣ DATI REALI</h3>
                  <p className="text-lg text-gray-300">
                    Fatturati e tasse pagate dalle multinazionali in Italia. Fonte: Bilanci pubblici certificati, ANAC, report settoriali ufficiali.
                  </p>
                </div>

                <div className="border-l-4 border-yellow-300 pl-8">
                  <h3 className="text-3xl font-black text-yellow-300 mb-4">2️⃣ PATENTE DIGITALE</h3>
                  <p className="text-lg text-gray-300">
                    Sistema proporzionale: chi fattura più contribuisce di più. Aliquota minima: 12% (uguale a quella di un panettiere).
                  </p>
                </div>

                <div className="border-l-4 border-green-500 pl-8">
                  <h3 className="text-3xl font-black text-green-500 mb-4">3️⃣ REDISTRIBUZIONE</h3>
                  <p className="text-lg text-gray-300">
                    Il 50% del gap recuperato va direttamente ai cittadini italiani, proporzionale al reddito. Tracciabilità totale su blockchain.
                  </p>
                </div>

                <div className="border-l-4 border-blue-500 pl-8">
                  <h3 className="text-3xl font-black text-blue-500 mb-4">4️⃣ RESPONSABILITÀ SOLIDALE</h3>
                  <p className="text-lg text-gray-300">
                    Se un gigante non paga, i suoi fornitori locali (logistica, hosting, pagamenti) rischiano il pignoramento. Il mercato si autoregola.
                  </p>
                </div>
              </div>
            </div>

            {/* THE MATH */}
            <div className="bg-black border-4 border-red-600 p-12">
              <h2 className="text-4xl font-black mb-8 text-red-600">LA MATEMATICA</h2>
              
              <div className="space-y-6 text-xl text-gray-300">
                <div>
                  <span className="font-bold text-yellow-300">Panettiere italiano:</span> Fatturato €200K → Paga ~€100K tasse (50%)
                </div>
                <div>
                  <span className="font-bold text-yellow-300">Amazon in Italia:</span> Fatturato €8.2Mld → Paga ~€410M tasse (5%)
                </div>
                <div>
                  <span className="font-bold text-red-600">LA DIFFERENZA È ILLEGALE, NON MATEMATICA.</span>
                </div>
                <div>
                  <span className="font-bold text-yellow-300">Con Patente Digitale:</span> Amazon pagherebbe €984M (12%) → Gap di €574M solo per Amazon
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="bg-red-600 border-4 border-red-700 p-12 text-center">
              <h2 className="text-5xl font-black mb-6 text-white">IL SILENZIO È UNA SCELTA</h2>
              <p className="text-2xl text-gray-100 mb-8">
                Questi dati sono pubblici. La matematica è inattaccabile.<br/>
                Ora che sai quanto ti spetta, cosa fai?
              </p>
              <div className="flex flex-col md:flex-row gap-4 justify-center">
                <a
                  href="mailto:protocollo.vichingo@proton.me"
                  className="py-6 px-12 bg-white text-red-600 font-black text-2xl hover:bg-gray-100 transition uppercase border-4 border-white"
                >
                  ✉️ CONTATTACI
                </a>
                <a
                  href="#"
                  className="py-6 px-12 bg-black text-white font-black text-2xl hover:bg-gray-900 transition uppercase border-4 border-white"
                >
                  📄 LEGGE COMPLETA
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="border-t-4 border-red-600 bg-black py-12 px-8 text-center">
        <p className="text-2xl font-black text-red-600 mb-4">PROTOCOLLO VICHINGO</p>
        <p className="text-lg text-gray-400 mb-6">Febbraio 2026 - La verità in numeri</p>
        <p className="text-sm text-gray-500 italic mb-6">
          "L'ordine nasce dal caos quando la misura incontra la pazienza"
        </p>
        <p className="text-sm text-gray-600">
          Contatti: <span className="text-white font-bold">protocollo.vichingo@proton.me</span>
        </p>
      </footer>
    </div>
  );
}
