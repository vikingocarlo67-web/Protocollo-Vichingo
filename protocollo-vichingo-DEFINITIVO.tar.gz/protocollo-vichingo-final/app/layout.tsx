import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Protocollo Vichingo - La Verità in Numeri",
  description: "Calcolatore di redistribuzione fiscale. Scopri quanto ti tornerebbe se i giganti pagassero il giusto.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="it">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>{children}</body>
    </html>
  );
}
